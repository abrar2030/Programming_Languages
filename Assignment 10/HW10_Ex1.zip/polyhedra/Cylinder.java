package polyhedra;

import java.lang.Math;

public class Cylinder extends Prism{

    int h,r;

    Cylinder(int h,int r){
        this.h = h;
        this.r = r;
    }

    @Override
    double baseArea() {
        return (Math.PI)*(Math.pow(r, 2));
    }

    @Override
    double volume() {
        return (baseArea()) * (super.height);
    }

    @Override
    public String toString() {
        return "baseArea : " + baseArea() + ",  volume : " + volume();
    }
    
}
