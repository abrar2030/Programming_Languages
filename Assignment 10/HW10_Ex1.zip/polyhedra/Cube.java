package polyhedra;

import java.lang.Math;

public class Cube extends Prism{

    int h;

    Cube(int h){
        this.h = h;
    }

    @Override
    double baseArea() {
        return Math.pow(h, 2);
    }

    @Override
    double volume() {
        return (baseArea()) * (super.height);
    }
    
    @Override
    public String toString() {
        return "baseArea : " + baseArea() + ",  volume : " + volume();
    }
}
