package polyhedra;

public abstract class Prism {
    
    int height = 5;

    abstract double baseArea();
    abstract double volume();
}
