package polyhedra;

public class MainPrism {
    public static void main(String[] args) {
    
    System.out.println("Cylinder : ");
    Cylinder c = new Cylinder(10, 5);
    System.out.println(c.toString());
    System.out.println("Cube : ");
    Cube b = new Cube(4);
    System.out.println(b.toString());

    }
}
