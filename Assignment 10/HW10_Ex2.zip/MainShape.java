public class MainShape {
    public static void main(String[] args) {
        System.out.println("Square : ");
        Square s = new Square(5);
        System.out.println(s.toString());
        System.out.println("Circle : ");
        Circle c = new Circle(5);
        System.out.println(c.toString());
        System.out.println("Rectangle: ");
        Rectangle r = new Rectangle(6,3);
        System.out.println(r.toString());
    }
}
