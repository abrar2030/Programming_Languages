public class Square implements Shape {
    int a;
    Square(int a){
        this.a = a;
    }
    @Override
    public double getPerimeter() {
            return (a*4);
    }

    @Override
    public double getArea() {
        return (a*a);
    }

    @Override
    public String toString() {
        return "Perimeter : " + getPerimeter() + ", Area : " + getPerimeter() ;
    }
    
}
