public class Rectangle implements Shape{

    int h,l;

    Rectangle(int h,int l){
        this.h = h;
        this.l = l;
    }

    @Override
    public double getPerimeter() {
        return (( h + l ) * 2);
    }

    @Override
    public double getArea() {
        return ( h * l );
    }

    @Override
    public String toString() {
        return "Perimeter : " + getPerimeter() + ", Area : " + getPerimeter() ;
    }
    
}
