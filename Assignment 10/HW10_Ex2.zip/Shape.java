public interface Shape {

    public double getPerimeter();
    public double getArea(); 
}

