
import java.lang.Math;

public class Circle implements Shape{
    double r;
    Circle(double r){
        this.r = r;
    }
    @Override
    public double getPerimeter() {
        return (Math.PI)*(2)*(r);
    }

    @Override
    public double getArea() {
        
        return (Math.PI)*(Math.pow(r, 2));
    }

    @Override
    public String toString() {
        return "Perimeter : " + getPerimeter() + ", Area : " + getPerimeter() ;
    }
    
}
